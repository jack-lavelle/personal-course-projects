#!/bin/bash
docker run --rm -it -v `pwd`:/home/microc -w=/home/microc columbiasedwards/plt
